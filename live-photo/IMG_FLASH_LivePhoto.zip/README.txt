Live Photo: IMG_FLASH
ContentIdentifier: EED93FA5-0EA0-42D9-AD0F-8C387EE315F9

Файлы (оба нужны, имена должны совпадать):
  IMG_FLASH.JPG  — ключевой кадр (луч включён)
  IMG_FLASH.MOV  — движение (мягкий свет → луч), ровно 2.0 с

Как попасть на iPhone:
1) На Mac перетащите оба файла вместе в «Фото» —
   они склеятся в Live Photo, дальше iCloud на iPhone.
2) На iPhone: скопируйте оба в «Файлы» и импортируйте
   парой через Live Photo Creator / ImgPlay / Lively.
3) Обои: Фото → Live Photo → Поделиться → Сделать обоями → Live вкл.

Эффект: нажали и держите — включается луч фонарика.
